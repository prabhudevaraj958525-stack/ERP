from __future__ import annotations

import os
from datetime import datetime, timedelta, date, timezone
from typing import Optional, List, Any
from contextlib import asynccontextmanager
from decimal import Decimal
import bcrypt

from fastapi import (
    FastAPI, Depends, HTTPException, status, Header, Query, APIRouter,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, Field, ConfigDict, field_validator
from pydantic_settings import BaseSettings
from jose import JWTError, jwt
from sqlalchemy import (
    String, Integer, Numeric, Boolean, DateTime, Date, ForeignKey,
    JSON, Text, func, select, event,
)
from sqlalchemy.orm import (
    DeclarativeBase, Mapped, mapped_column, relationship, Session,
)
from sqlalchemy.ext.asyncio import (
    create_async_engine, AsyncSession, async_sessionmaker,
)


# ============================================================
# 1. CONFIGURATION (Pydantic v2 Settings)
# ============================================================
class Settings(BaseSettings):
    PROJECT_NAME: str = "Axalin ERP API"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"

    # Use SQLite for zero-setup demo. Swap to PostgreSQL 16 in prod:
    # postgresql+asyncpg://axalin:axalin_secret@localhost:5432/axalin_erp
    DATABASE_URL: str = "sqlite+aiosqlite:///./axalin_erp.db"

    SECRET_KEY: str = "CHANGE-ME-IN-PRODUCTION-use-openssl-rand-hex-32"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_BROKER: str = "redis://localhost:6379/1"

    model_config = ConfigDict(env_file=".env", case_sensitive=True)


settings = Settings()


# ============================================================
# 2. DATABASE (SQLAlchemy 2.0 Async)
# ============================================================
class Base(DeclarativeBase):
    pass


engine = create_async_engine(settings.DATABASE_URL, echo=False, future=True)
AsyncSessionLocal = async_sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)


async def get_db() -> AsyncSession:
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


# ============================================================
# 3. MODELS (PostgreSQL 16 ready — JSONB, RLS-friendly)
# ============================================================
class Tenant(Base):
    __tablename__ = "tenants"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    gstin: Mapped[Optional[str]] = mapped_column(String(15), unique=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    config: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class Branch(Base):
    __tablename__ = "branches"
    id: Mapped[int] = mapped_column(primary_key=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"))
    name: Mapped[str] = mapped_column(String(200))
    gstin: Mapped[Optional[str]] = mapped_column(String(15))
    address: Mapped[str] = mapped_column(Text, default="")


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"))
    branch_id: Mapped[Optional[int]] = mapped_column(ForeignKey("branches.id"))
    email: Mapped[str] = mapped_column(String(200), unique=True)
    hashed_password: Mapped[str] = mapped_column(String(200))
    full_name: Mapped[str] = mapped_column(String(200))
    role: Mapped[str] = mapped_column(String(50))  # admin | cashier | manager | staff
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(primary_key=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"))
    sku: Mapped[str] = mapped_column(String(100), unique=True)
    name: Mapped[str] = mapped_column(String(300))
    hsn_code: Mapped[str] = mapped_column(String(20))
    gst_rate: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=18)
    price: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    cost: Mapped[Decimal] = mapped_column(Numeric(12, 2), default=0)
    attributes: Mapped[dict] = mapped_column(JSON, default=dict)  # JSONB in PG


class Inventory(Base):
    __tablename__ = "inventory"
    id: Mapped[int] = mapped_column(primary_key=True)
    branch_id: Mapped[int] = mapped_column(ForeignKey("branches.id"))
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    qty: Mapped[int] = mapped_column(Integer, default=0)
    batch: Mapped[Optional[str]] = mapped_column(String(100))
    expiry: Mapped[Optional[date]] = mapped_column(Date)


class Customer(Base):
    __tablename__ = "customers"
    id: Mapped[int] = mapped_column(primary_key=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"))
    name: Mapped[str] = mapped_column(String(200))
    mobile: Mapped[str] = mapped_column(String(20))
    gstin: Mapped[Optional[str]] = mapped_column(String(15))
    loyalty_points: Mapped[int] = mapped_column(Integer, default=0)
    aadhaar_verified: Mapped[bool] = mapped_column(Boolean, default=False)


class Sale(Base):
    __tablename__ = "sales"
    id: Mapped[int] = mapped_column(primary_key=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"))
    branch_id: Mapped[int] = mapped_column(ForeignKey("branches.id"))
    customer_id: Mapped[Optional[int]] = mapped_column(ForeignKey("customers.id"))
    cashier_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    subtotal: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    gst_amount: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    total: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    payment_mode: Mapped[str] = mapped_column(String(50))  # upi | card | cash | split
    irn: Mapped[Optional[str]] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"))
    supplier_name: Mapped[str] = mapped_column(String(200))
    supplier_gstin: Mapped[str] = mapped_column(String(15))
    total: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    tds_deducted: Mapped[Decimal] = mapped_column(Numeric(12, 2), default=0)
    status: Mapped[str] = mapped_column(String(30), default="draft")  # draft|grn_done|invoiced|paid
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class ComplianceJob(Base):
    __tablename__ = "compliance_jobs"
    id: Mapped[int] = mapped_column(primary_key=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"))
    job_type: Mapped[str] = mapped_column(String(50))  # irn|ewaybill|gstr1|gstr2b|tds
    status: Mapped[str] = mapped_column(String(30), default="pending")
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    result: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


# ============================================================
# 4. PYDANTIC SCHEMAS (v2)
# ============================================================
class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class TokenPayload(BaseModel):
    sub: str
    tenant_id: int
    branch_id: Optional[int] = None
    role: str
    exp: datetime


class UserCreate(BaseModel):
    email: str
    password: str
    full_name: str
    role: str = "staff"
    tenant_id: int
    branch_id: Optional[int] = None


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    email: str
    full_name: str
    role: str
    tenant_id: int
    branch_id: Optional[int]


class ProductCreate(BaseModel):
    sku: str
    name: str
    hsn_code: str
    gst_rate: Decimal = 18
    price: Decimal
    cost: Decimal = 0
    attributes: dict = {}

    @field_validator("hsn_code")
    @classmethod
    def validate_hsn(cls, v: str) -> str:
        if not v.isdigit() or len(v) not in (4, 6, 8):
            raise ValueError("HSN must be 4/6/8 digits")
        return v


class ProductOut(ProductCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int


class SaleItemIn(BaseModel):
    product_id: int
    qty: int


class SaleCreate(BaseModel):
    customer_id: Optional[int] = None
    items: List[SaleItemIn]
    payment_mode: str = "cash"


class SaleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    total: Decimal
    gst_amount: Decimal
    irn: Optional[str]
    created_at: datetime


class CustomerCreate(BaseModel):
    name: str
    mobile: str
    gstin: Optional[str] = None


class CustomerOut(CustomerCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    loyalty_points: int


class ComplianceJobOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    job_type: str
    status: str
    created_at: datetime


# ============================================================
# 5. AUTH (Direct bcrypt fix for modern environments)
# ============================================================
oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_STR}/auth/login")


def hash_password(pw: str) -> str:
    pwd_bytes = pw.encode('utf-8')
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(pwd_bytes, salt).decode('utf-8')


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode('utf-8'), hashed.encode('utf-8'))


def create_token(data: dict, expires_delta: timedelta) -> str:
    to_encode = data.copy()
    to_encode["exp"] = datetime.now(timezone.utc) + expires_delta
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def create_access_token(user: User) -> str:
    return create_token(
        {"sub": user.email, "tenant_id": user.tenant_id,
         "branch_id": user.branch_id, "role": user.role},
        timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
    )


def create_refresh_token(user: User) -> str:
    return create_token(
        {"sub": user.email, "type": "refresh"},
        timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
    )


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    credentials_exc = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired token",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exc
    except JWTError:
        raise credentials_exc

    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()
    if user is None or not user.is_active:
        raise credentials_exc
    return user


def require_role(*roles: str):
    async def checker(user: User = Depends(get_current_user)):
        if user.role not in roles:
            raise HTTPException(status_code=403, detail="Insufficient role")
        return user
    return checker


# ============================================================
# 6. CELERY TASK STUBS (Compliance Engine — separate queue)
# ============================================================
class CeleryStub:
    """Placeholder — replace with real Celery app in production."""
    @staticmethod
    def send_task(name: str, kwargs: dict, queue: str = "default"):
        print(f"[Celery:{queue}] Dispatched {name} with {kwargs}")


def dispatch_irn(sale_id: int, tenant_id: int):
    CeleryStub.send_task("compliance.generate_irn",
                         {"sale_id": sale_id, "tenant_id": tenant_id},
                         queue="compliance")


def dispatch_eway_bill(po_id: int, tenant_id: int):
    CeleryStub.send_task("compliance.generate_eway_bill",
                         {"po_id": po_id, "tenant_id": tenant_id},
                         queue="compliance")


def dispatch_gstr1_assembly(tenant_id: int, month: str):
    CeleryStub.send_task("compliance.assemble_gstr1",
                         {"tenant_id": tenant_id, "month": month},
                         queue="compliance")


# ============================================================
# 7. ROUTES — AUTH
# ============================================================
auth_router = APIRouter(prefix="/auth", tags=["Auth"])


@auth_router.post("/login", response_model=Token)
async def login(form: OAuth2PasswordRequestForm = Depends(),
                db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.email == form.username))
    user = result.scalar_one_or_none()
    if not user or not verify_password(form.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return Token(
        access_token=create_access_token(user),
        refresh_token=create_refresh_token(user),
    )


@auth_router.get("/me", response_model=UserOut)
async def me(user: User = Depends(get_current_user)):
    return user


# ============================================================
# 8. ROUTES — PRODUCTS (Inventory Master)
# ============================================================
products_router = APIRouter(prefix="/products", tags=["Inventory"])


@products_router.post("/", response_model=ProductOut, status_code=201)
async def create_product(
    data: ProductCreate,
    user: User = Depends(require_role("admin", "manager")),
    db: AsyncSession = Depends(get_db),
):
    product = Product(tenant_id=user.tenant_id, **data.model_dump())
    db.add(product)
    await db.commit()
    await db.refresh(product)
    return product


@products_router.get("/", response_model=List[ProductOut])
async def list_products(
    q: Optional[str] = None,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(Product).where(Product.tenant_id == user.tenant_id)
    if q:
        stmt = stmt.where(Product.name.ilike(f"%{q}%"))
    result = await db.execute(stmt)
    return result.scalars().all()


# ============================================================
# 9. ROUTES — POS / SALES
# ============================================================
sales_router = APIRouter(prefix="/sales", tags=["POS/Sales"])


@sales_router.post("/", response_model=SaleOut, status_code=201)
async def create_sale(
    data: SaleCreate,
    user: User = Depends(require_role("admin", "cashier", "manager")),
    db: AsyncSession = Depends(get_db),
):
    subtotal = Decimal("0")
    gst_total = Decimal("0")

    for item in data.items:
        prod = await db.get(Product, item.product_id)
        if not prod or prod.tenant_id != user.tenant_id:
            raise HTTPException(404, f"Product {item.product_id} not found")
        inv = (await db.execute(
            select(Inventory).where(
                Inventory.product_id == prod.id,
                Inventory.branch_id == user.branch_id,
            )
        )).scalar_one_or_none()
        if not inv or inv.qty < item.qty:
            raise HTTPException(400, f"Insufficient stock for {prod.sku}")

        line_total = prod.price * item.qty
        line_gst = (line_total * prod.gst_rate / Decimal("100"))
        subtotal += line_total
        gst_total += line_gst
        inv.qty -= item.qty

    sale = Sale(
        tenant_id=user.tenant_id,
        branch_id=user.branch_id,
        customer_id=data.customer_id,
        cashier_id=user.id,
        subtotal=subtotal,
        gst_amount=gst_total,
        total=subtotal + gst_total,
        payment_mode=data.payment_mode,
    )
    db.add(sale)
    await db.commit()
    await db.refresh(sale)

    dispatch_irn(sale.id, sale.tenant_id)
    return sale


@sales_router.get("/", response_model=List[SaleOut])
async def list_sales(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(Sale).where(Sale.tenant_id == user.tenant_id)
    if user.role != "admin":
        stmt = stmt.where(Sale.branch_id == user.branch_id)
    result = await db.execute(stmt.order_by(Sale.created_at.desc()).limit(100))
    return result.scalars().all()


# ============================================================
# 10. ROUTES — CUSTOMERS (CRM)
# ============================================================
crm_router = APIRouter(prefix="/customers", tags=["CRM"])


@crm_router.post("/", response_model=CustomerOut, status_code=201)
async def create_customer(
    data: CustomerCreate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    cust = Customer(tenant_id=user.tenant_id, **data.model_dump())
    db.add(cust)
    await db.commit()
    await db.refresh(cust)
    return cust


@crm_router.get("/", response_model=List[CustomerOut])
async def list_customers(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Customer).where(Customer.tenant_id == user.tenant_id)
    )
    return result.scalars().all()


# ============================================================
# 11. ROUTES — PURCHASING
# ============================================================
purchasing_router = APIRouter(prefix="/purchases", tags=["Purchasing"])


@purchasing_router.post("/", status_code=201)
async def create_purchase_order(
    supplier_name: str,
    supplier_gstin: str,
    total: Decimal,
    user: User = Depends(require_role("admin", "manager")),
    db: AsyncSession = Depends(get_db),
):
    po = PurchaseOrder(
        tenant_id=user.tenant_id,
        supplier_name=supplier_name,
        supplier_gstin=supplier_gstin,
        total=total,
    )
    db.add(po)
    await db.commit()
    await db.refresh(po)
    return {"id": po.id, "status": po.status}


@purchasing_router.post("/{po_id}/dispatch-eway")
async def dispatch_eway(
    po_id: int,
    user: User = Depends(require_role("admin", "manager")),
    db: AsyncSession = Depends(get_db),
):
    po = await db.get(PurchaseOrder, po_id)
    if not po or po.tenant_id != user.tenant_id:
        raise HTTPException(404, "PO not found")
    dispatch_eway_bill(po.id, po.tenant_id)
    return {"message": "E-Way Bill generation queued", "po_id": po.id}


# ============================================================
# 12. ROUTES — COMPLIANCE (GST, IRN, GSTR, TDS)
# ============================================================
compliance_router = APIRouter(prefix="/compliance", tags=["GST Compliance"])


@compliance_router.post("/gstr1/assemble")
async def assemble_gstr1(
    month: str = Query(..., pattern=r"^\d{4}-\d{2}$"),
    user: User = Depends(require_role("admin")),
):
    dispatch_gstr1_assembly(user.tenant_id, month)
    return {"message": f"GSTR-1 assembly queued for {month}", "tenant_id": user.tenant_id}


@compliance_router.get("/jobs", response_model=List[ComplianceJobOut])
async def list_jobs(
    user: User = Depends(require_role("admin")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(ComplianceJob)
        .where(ComplianceJob.tenant_id == user.tenant_id)
        .order_by(ComplianceJob.created_at.desc())
        .limit(50)
    )
    return result.scalars().all()


# ============================================================
# 13. ROUTES — FINANCE (stub)
# ============================================================
finance_router = APIRouter(prefix="/finance", tags=["Finance"])


@finance_router.get("/trial-balance")
async def trial_balance(user: User = Depends(require_role("admin", "manager"))):
    return {
        "tenant_id": user.tenant_id,
        "period": "FY 2026-27",
        "accounts": [
            {"code": "1001", "name": "Cash", "debit": 50000, "credit": 0},
            {"code": "2001", "name": "GST Payable", "debit": 0, "credit": 9000},
        ],
        "balanced": True,
    }


# ============================================================
# 14. HEALTH CHECK / LIFECYCLE (Isolated Seeding Fix)
# ============================================================
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Create tables safely
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        
    # Seed data safely within an explicit async transaction context
    async with AsyncSessionLocal() as db:
        async with db.begin():
            result = await db.execute(select(Tenant).limit(1))
            exists = result.scalar_one_or_none()
            
            if not exists:
                tenant = Tenant(name="Demo Retail Pvt Ltd", gstin="27AAAAA0000A1Z5")
                db.add(tenant)
                await db.flush()  # Populates tenant.id dynamically
                
                branch = Branch(name="Mumbai Store", gstin="27AAAAA0000A1Z5", tenant_id=tenant.id)
                db.add(branch)
                await db.flush()  # Populates branch.id dynamically
                
                admin = User(
                    tenant_id=tenant.id, 
                    branch_id=branch.id,
                    email="admin@axalin.io", 
                    hashed_password=hash_password("admin123"),
                    full_name="Admin User", 
                    role="admin",
                )
                db.add(admin)
                await db.commit()
    yield


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router, prefix=settings.API_V1_STR)
app.include_router(products_router, prefix=settings.API_V1_STR)
app.include_router(sales_router, prefix=settings.API_V1_STR)
app.include_router(crm_router, prefix=settings.API_V1_STR)
app.include_router(purchasing_router, prefix=settings.API_V1_STR)
app.include_router(compliance_router, prefix=settings.API_V1_STR)
app.include_router(finance_router, prefix=settings.API_V1_STR)


@app.get("/")
async def root():
    return {
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "docs": "/docs",
        "demo_login": {"username": "admin@axalin.io", "password": "admin123"},
    }


# ============================================================
# 15. RUN
# ============================================================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "axalin_erp:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )